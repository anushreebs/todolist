import firebase from 'firebase'
import 'firebase/auth'
import 'firebase/firestore'

// const firebaseConfig = {
//     apiKey: "AIzaSyCuYQBgQfFari359VVfxA9jbXclPNAhel8",
//     authDomain: "todoappwithreactandfirebase.firebaseapp.com",
//     projectId: "todoappwithreactandfirebase",
//     messagingSenderId: "167166982530",
//     appId: "1:167166982530:web:fcc25dda0d91b586f1b79b",
//     measurementId: "G-JG8TVXR2L4"
//   };
// const firebaseConfig = {
//   apiKey: "AIzaSyBCaHtr68qGQ_seHkY1sS_xlJF7HqpQ8YY",
//   authDomain: "todoappwithreactandfireb-fa5bb.firebaseapp.com",
//   databaseURL: "https://todoappwithreactandfireb-fa5bb-default-rtdb.firebaseio.com",
//   projectId: "todoappwithreactandfireb-fa5bb",
//   storageBucket: "todoappwithreactandfireb-fa5bb.appspot.com",
//   messagingSenderId: "389421185012",
//   appId: "1:389421185012:web:de48bf6712d9872fbbeba1",
//   measurementId: "G-VJDCYS6QP5"
// };
const firebaseConfig = {
  apiKey: "AIzaSyDn1_nPhcCD1QD33hbKurc2Eom2RAqjQ4c",
  authDomain: "todoappwithreactandfireb-95eb0.firebaseapp.com",
  projectId: "todoappwithreactandfireb-95eb0",
  storageBucket: "todoappwithreactandfireb-95eb0.appspot.com",
  messagingSenderId: "57470044893",
  appId: "1:57470044893:web:d9583d9790e44b2be66934"
};
  firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();

export { auth, db} 