import React from 'react'

export const NotFound = () => {
    return (
        <div>
            not found
        </div>
    )
}
